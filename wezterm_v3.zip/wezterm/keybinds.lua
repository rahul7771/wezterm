local wezterm = require("wezterm")
local act = wezterm.action
local module = {}

function module.apply_to_config(config)
	-- CTRL + SPACE as leader
-- config.leader = {
-- 	key = " ",
-- 	mods = "CTRL",
-- 	timeout_milliseconds = 2000,
-- }
	 config.send_composed_key_when_left_alt_is_pressed = true
	 config.send_composed_key_when_right_alt_is_pressed = true
	 config.keys = {
	-- 	-- custom script keybinds
	-- 	{
	-- 		key = "i",
	-- 		mods = "CMD | SHIFT",
	-- 		action = act.EmitEvent("trigger-pin-input"),
	-- 	},
	--
	-- 	-- Normal keybinds
	-- 	{
	-- 		key = "[",
	-- 		mods = "LEADER",
	-- 		action = act.ActivateCopyMode,
	-- 	},
	-- 	{
	-- 		key = "c",
	-- 		mods = "LEADER",
	-- 		action = act.SpawnTab("CurrentPaneDomain"),
	-- 	},
	-- 	{
	-- 		key = "|",
	-- 		mods = "LEADER",
	-- 		action = act.SplitHorizontal({ domain = "CurrentPaneDomain" }),
	-- 	},
	-- 	{
	-- 		key = "_",
	-- 		mods = "LEADER",
	-- 		action = act.SplitVertical({ domain = "CurrentPaneDomain" }),
	-- 	},
	-- 	{
	-- 		key = "h",
	-- 		mods = "ALT | SHIFT",
	-- 		action = act.ActivateTabRelative(-1),
	-- 	},
	-- 	{
	-- 		key = "l",
	-- 		mods = "ALT | SHIFT",
	-- 		action = act.ActivateTabRelative(1),
	-- 	},
	-- 	{
	-- 		key = "f",
	-- 		mods = "ALT | SHIFT",
	-- 		action = act.ShowLauncherArgs({
	-- 			flags = "FUZZY|WORKSPACES",
	-- 		}),
	-- 	},
	-- 	-- Similar to tmux sessionizer
	-- 	{
	-- 		key = "f",
	-- 		mods = "CTRL",
	-- 		action = require("wez-per-project-workspace.plugin").action.ProjectWorkspaceSelect({
	-- 			base_dirs = {
	-- 				-- {
	-- 				-- 	path = "/Users/debsishu/Desktop/Amazon",
	-- 				-- 	min_depth = 1,
	-- 				-- 	max_depth = 1,
	-- 				-- },
	-- 				-- {
	-- 				-- 	path = "/Users/debsishu/Desktop/Work",
	-- 				-- 	min_depth = 1,
	-- 				-- 	max_depth = 1,
	-- 				-- },
	-- 				{
	-- 					path = "/Users/rahuld/workplace/",
	-- 					min_depth = 1,
	-- 					max_depth = 1,
	-- 				},
	-- 				{
	-- 					path = "/Users/rahuld/workplace/",
	-- 					min_depth = 1,
	-- 					max_depth = 1,
	-- 				},
	-- 			},
	-- 			rooters = { "packageInfo", ".git" },
	-- 			shorten_paths = false,
	-- 		}),
	-- 	},
	-- 	-- {
	-- 	-- 	key = "f",
	-- 	-- 	mods = "CTRL",
	-- 	-- 	action = wezterm.action_callback(require("wezterm-sessionizer.plugin").toggle),
	-- 	-- },
	-- 	{ key = "h", mods = "CTRL", action = act.EmitEvent("ActivatePaneDirection-left") },
	-- 	{ key = "j", mods = "CTRL", action = act.EmitEvent("ActivatePaneDirection-down") },
	-- 	{ key = "k", mods = "CTRL", action = act.EmitEvent("ActivatePaneDirection-up") },
	-- 	{ key = "l", mods = "CTRL", action = act.EmitEvent("ActivatePaneDirection-right") },
	 	{ key = "LeftArrow", mods = "OPT", action = wezterm.action({ SendString = "\x1bb" }) },
	 	{ key = "RightArrow", mods = "OPT", action = wezterm.action({ SendString = "\x1bf" }) },
	-- 	{
	-- 		key = "Escape",
	-- 		mods = "LEADER",
	-- 		action = act.Multiple({
	-- 			act.CopyMode("ClearPattern"),
	-- 			act.CopyMode("AcceptPattern"),
	-- 			act.CopyMode({ SetSelectionMode = "Cell" }),
	-- 		}),
	-- 	},
	}
end

return module


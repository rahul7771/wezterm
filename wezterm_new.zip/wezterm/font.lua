local wezterm = require("wezterm")
local module = {}

function module.apply_to_config(config)
	config.font = wezterm.font("JetBrainsMono Nerd Font", { weight = "Medium" })
	config.font_size = 16
	config.line_height = 1.12
end

return module
